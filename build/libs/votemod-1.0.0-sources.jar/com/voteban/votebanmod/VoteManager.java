package com.voteban.votebanmod;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_11560;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3336;
import net.minecraft.server.MinecraftServer;
import java.util.Date;


public class VoteManager {

    private static String banTime = "1h";

    public static void setBanTime(String time) {
        banTime = time;
    }

    public static String getBanTime() {
        return banTime;
    }
    private static VoteSession activeVote;

    public static boolean hasActiveVote() {
        return activeVote != null;
    }

    public static VoteSession getActiveVote() {
        return activeVote;
    }

    private static Date getBanExpiryDate() {
    String time = banTime.toLowerCase();

    if (time.equals("permanent") || time.equals("perm")) {
        return null;
    }

    if (time.equals("1d")) {
        return new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
    }

    return new Date(System.currentTimeMillis() + 60 * 60 * 1000);
}

    public static void startVote(MinecraftServer server, class_3222 starter, class_3222 target, String reason) {
        activeVote = new VoteSession(
                target.method_5667(),
                target.method_5477().getString(),
                starter.method_5667(),
                reason
        );

        server.method_3760().method_43514(
                class_2561.method_43470("Vote started to kick " + target.method_5477().getString()
                        + " for: " + reason
                        + " | Type /voteban yes or /voteban no"),
                false
        );
    }

    public static void vote(class_3222 player, boolean yes) {
        if (activeVote == null) {
            player.method_64398(class_2561.method_43470("No active vote."));
            return;
        }

        activeVote.votes.put(player.method_5667(), yes);
        player.method_64398(class_2561.method_43470("Vote counted."));
    }

    public static void registerTickEvent() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (activeVote != null && activeVote.hasExpired()) {
                finishVote(server);
            }
        });
    }

    private static void finishVote(MinecraftServer server) {
        int yes = activeVote.getYesVotes();
        int no = activeVote.getNoVotes();
        int total = yes + no;

        boolean passed = total >= 3 && yes >= Math.ceil(total * 0.7);

        if (passed) {
            class_3222 target = server.method_3760().method_14602(activeVote.targetId);

            if (target != null) {
                Date created = new Date();
                Date expires = getBanExpiryDate();
                server.method_3760().method_14563().method_74006(
        new class_3336(
                new class_11560(target.method_5667(), target.method_5477().getString()),
                created,
                "VoteBan",
                expires,
                activeVote.reason
        )
);

    target.field_13987.method_52396(
            class_2561.method_43470("You were banned by vote for: " + banTime + "\nReason: " + activeVote.reason)
    );
}
           

            server.method_3760().method_43514(
                    class_2561.method_43470("Vote passed. " + activeVote.targetName + " was kicked."),
                    false
            );
        } else {
            server.method_3760().method_43514(
                    class_2561.method_43470("Vote failed. Yes: " + yes + " No: " + no),
                    false
            );
        }

        activeVote = null;
    }
}