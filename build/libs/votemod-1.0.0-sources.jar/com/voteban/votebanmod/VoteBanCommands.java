package com.voteban.votebanmod;

import com.mojang.brigadier.arguments.StringArgumentType;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_12099;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;


public class VoteBanCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(class_2170.method_9247("voteban")

                    .then(class_2170.method_9247("start")
                            .then(class_2170.method_9244("target", class_2186.method_9305())
                                    .then(class_2170.method_9244("reason", StringArgumentType.greedyString())
                                            .executes(ctx -> {
                                                class_3222 starter = ctx.getSource().method_44023();
                                                class_3222 target = class_2186.method_9315(ctx, "target");
                                                String reason = StringArgumentType.getString(ctx, "reason");

                                                if (VoteManager.hasActiveVote()) {
                                                    starter.method_64398(class_2561.method_43470("Vote already active."));
                                                    return 0;
                                                }

                                                if (ProtectedPlayers.isProtected(target)) {
                                                    starter.method_64398(class_2561.method_43470("This player is protected and cannot be vote-kicked."));
                                                    return 0;
                                                }

                                                VoteManager.startVote(ctx.getSource().method_9211(), starter, target, reason);
                                                return 1;
                                            })
                                    )
                            )
                    )

                    .then(class_2170.method_9247("yes").executes(ctx -> {
                        VoteManager.vote(ctx.getSource().method_44023(), true);
                        return 1;
                    }))

                    .then(class_2170.method_9247("no").executes(ctx -> {
                        VoteManager.vote(ctx.getSource().method_44023(), false);
                        return 1;
                    }))

                    .then(class_2170.method_9247("status").executes(ctx -> {
                        class_3222 player = ctx.getSource().method_44023();
                        VoteSession vote = VoteManager.getActiveVote();

                        if (vote == null) {
                            player.method_64398(class_2561.method_43470("No vote active."));
                            return 0;
                        }

                        player.method_64398(class_2561.method_43470(
                                "Voting on " + vote.targetName +
                                        " | Yes: " + vote.getYesVotes() +
                                        " | No: " + vote.getNoVotes()
                        ));

                        return 1;
                    }))
            );

            dispatcher.register(class_2170.method_9247("votebanadmin")
                 .requires(source -> source.method_75037().hasPermission(class_12099.field_63209))
                    .then(class_2170.method_9247("add")
                   
                            .then(class_2170.method_9244("player", class_2186.method_9305())
                                    .executes(ctx -> {

                                        class_3222 player = class_2186.method_9315(ctx, "player");

                                        ProtectedPlayers.add(player);

                                        ctx.getSource().method_9226(
                                                () -> class_2561.method_43470(player.method_5477().getString() + " is now protected from vote bans."),
                                                true
                                        );

                                        return 1;
                                    })
                            )
                    )

                    .then(class_2170.method_9247("remove")
                            .then(class_2170.method_9244("player", class_2186.method_9305())
                                    .executes(ctx -> {

                                        class_3222 player = class_2186.method_9315(ctx, "player");

                                        ProtectedPlayers.remove(player);

                                        ctx.getSource().method_9226(
                                                () -> class_2561.method_43470(player.method_5477().getString() + " is no longer protected from vote bans."),
                                                true
                                        );

                                        return 1;
                                    })
                            )
                    )
                    .then(class_2170.method_9247("bantime")
        .then(class_2170.method_9244("time", StringArgumentType.word())
                .executes(ctx -> {
                    String time = StringArgumentType.getString(ctx, "time").toLowerCase();

                    if (!time.equals("1h") && !time.equals("1d") && !time.equals("permanent") && !time.equals("perm")) {
                        ctx.getSource().method_9213(class_2561.method_43470("Invalid ban time. Use: 1h, 1d, or permanent."));
                        return 0;
                    }

                    if (time.equals("perm")) {
                        time = "permanent";
                    }

                    VoteManager.setBanTime(time);

                    ctx.getSource().method_9226(
                            () -> class_2561.method_43470("Vote ban time set to: " + VoteManager.getBanTime()),
                            true
                    );

                    return 1;
                })
        )
)
            );
        });
    }
}